require("./global")

const mess = {
   wait: "Wait Sis, it's still being processed",
   success: "Sukses Kak`",
   on: "Wait Sis, it's still in progress", 
   off: "OFF",
   query: {
       text: "Where's the text, sis?",
       link: "Where's the link, sis?",
   },
   error: {
       fitur: "Sorry, there is an error in the feature. Please chat with the Bot Developer so it can be fixed immediately.",
   },
   only: {
       group: "Sorry, this feature can only be used in groups.",
       private: "Maaf Kak Fitur Ini Hanya Bisa Digunakan Di Dalam Private Chat",
       owner: "Sorry, this feature can only be used by bot owners.",
       admin: "Sorry, this feature can only be used by bot owners.",
       badmin: "Sorry, Sis, It Looks Like You Can't Use This Feature Because the Bot is Not a Group Admin",
       premium: "Sorry, you are not a premium user yet. To become a premium user, please buy from the owner by typing .owner",
   }
}

global.mess = mess

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})