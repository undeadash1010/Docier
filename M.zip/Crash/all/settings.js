require("./module")
global.owner = "923164413714" 
global.namabot = "NOAH"
global.namaCreator = "MODS" 
global.autoJoin = false 
global.antilink = false 
global.versisc = 'V.5.0'
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = 'https://anjay-kintol.com' 
global.apikey = 'plta_' 
global.capikey = 'pltc_' 
global.eggsnya = 'V5' 
global.location = '1' 
global.imageurl = 'https://telegra.ph/file/5499996f06bce81d47202.jpg' 
global.imageurl2 = 'https://telegra.ph/file/95b545d3efee76c3591fd.jpg'
global.isLink = '' 
global.thumb = fs.readFileSync("./thumb.png")
global.audionya = fs.readFileSync("./all/sound.mp3") 
global.rezzx9 = '' 
global.rezzx1 = '' 
global.rezzx2 = '' 
global.rezzx3 = '' 
global.rezzx4 = ''
global.rezzx5 = ''
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.packname = "� Created By" 
global.author = "NOAH" 
global.jumlah = "GG"
global.dana = "923164413714" 
global.gopay = "923164413714" 
global.ovo = ""

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})



